<div class="container" id="main">    
    <div class="register">
		<div class="container">
			<h2>Register Here</h2>
			<div class="login-form-grids">
				<form method="post" action="" class="form-horizontal" role="form">
                     <?php if(!empty(@$notif)){ ?>
                        <div id="signupalert" class="alert alert-<?php echo @$notif['type'];?>">
                            <p><?php echo @$notif['message'];?></p>
                            <span></span>
                        </div>
                    <?php } ?>
				    <h5>Login information</h5>
                    <input type="text"  name="uname" id="uname" placeholder="User Name"  required value="<?php echo $this->input->post('uname');?>">
                    <input type="email"  name="email" id="email"  placeholder="Email Address" onchange="m1()" value="<?php echo $this->input->post('email');?>">
					<input type="password" name="password"  id="password" placeholder="Password" onchange="passs()" value="<?php echo $this->input->post('password');?>">
					<input type="text"  name="confirm_password" id="confirm_password" placeholder="Confirm Password" onchange="cop()" required value="<?php echo $this->input->post('confirm_password');?>">
                    <div> </div>
                    <div class="register-check-box">
						<div class="check">
                            <?php  
                               $checked ='';
                               if(count($_POST)){
                                   if($this->input->post('is_active'))  $checked ='checked';
                               }
                               else $checked ='checked';
                            ?>
                            <input type="checkbox" name="is_active" value="1" <?php echo $checked;?>> <label class="checkbox">I accept the terms and conditions</label>
                        </div>
                    </div>
					<input type="submit" value="Register">
				</form>
			</div>
		</div>
	</div>
</div>

<script>
    function ml(){

         var val_email= /^[a-zA-Z0-9._-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,4}$/;;
         $l_email= document.getElementById('email').value;

         if(!val_email.test($l_email)){

          alert("Enter proper Email address");
           document.getElementById('email').value='';
           $("#email").focus();
          return false;
        }

    }
    function cop() {
        $paswd = document.getElementById('password').value;
        //document.getElementById('message').style.color = "red";
        $confirm= document.getElementById('confirm_password').value;
        if($confirm!=$paswd)
        {
         alert("password mismatch");
           document.getElementById('confirm_password').value="";

        }
    }
     function passs(){

         var valemail= /(?=.*\d)(?=.*[a-z])(?=.*[A-Z]).{6,}/; 
         $l_email= document.getElementById('password').value;

         if(!valemail.test($l_email)){

          alert("Must contain at least one number and one uppercase and lowercase letter, and at least 6 or more characters");
           document.getElementById('password').value='';
           $("#password").focus();
          return false;
        }
    }
    </script>
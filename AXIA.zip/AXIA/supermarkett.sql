-- phpMyAdmin SQL Dump
-- version 4.7.4
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1:3306
-- Generation Time: Sep 14, 2018 at 10:46 AM
-- Server version: 5.7.19
-- PHP Version: 5.6.31

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `supermarkett`
--

-- --------------------------------------------------------

--
-- Table structure for table `category`
--

DROP TABLE IF EXISTS `category`;
CREATE TABLE IF NOT EXISTS `category` (
  `cat_id` int(11) NOT NULL AUTO_INCREMENT,
  `cat_name` varchar(100) NOT NULL,
  `cat_status` int(11) NOT NULL DEFAULT '1',
  `cat_created_At` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`cat_id`)
) ENGINE=InnoDB AUTO_INCREMENT=24 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `category`
--

INSERT INTO `category` (`cat_id`, `cat_name`, `cat_status`, `cat_created_At`) VALUES
(1, 'Electronics', 1, '2018-07-31 18:30:00'),
(7, 'Toys', 0, '2018-09-03 19:23:26'),
(17, 'Cloths', 0, '2018-09-12 05:08:22'),
(18, 'Backery', 0, '2018-09-12 09:14:23'),
(19, 'hhhh', 1, '2018-09-12 16:27:23'),
(21, 'uioo', 1, '2018-09-12 16:29:19'),
(22, '234', 0, '2018-09-12 16:33:29'),
(23, 'asd', 1, '2018-09-13 03:26:06');

-- --------------------------------------------------------

--
-- Table structure for table `customer`
--

DROP TABLE IF EXISTS `customer`;
CREATE TABLE IF NOT EXISTS `customer` (
  `customer_id` int(11) NOT NULL AUTO_INCREMENT,
  `cus_first_name` varchar(30) NOT NULL,
  `cus_last_name` varchar(30) NOT NULL,
  `cus_phone` varchar(30) NOT NULL,
  `cus_address` varchar(200) NOT NULL,
  `cus_gender` int(11) NOT NULL DEFAULT '1',
  `cus_dob` date NOT NULL,
  `users_id` int(11) NOT NULL,
  PRIMARY KEY (`customer_id`)
) ENGINE=InnoDB AUTO_INCREMENT=11 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `customer`
--

INSERT INTO `customer` (`customer_id`, `cus_first_name`, `cus_last_name`, `cus_phone`, `cus_address`, `cus_gender`, `cus_dob`, `users_id`) VALUES
(8, 'Sobin', 'Mathew', '9633845820', 'pullumattathil vadakkemala', 1, '2018-09-09', 9),
(9, 'Nashi', 'Ramees', '9526254541', 'Pullickal', 2, '1994-01-01', 23),
(10, 'KIchu', 'Mathew', '6545123208', 'asdf', 1, '1920-01-29', 42);

-- --------------------------------------------------------

--
-- Table structure for table `designation`
--

DROP TABLE IF EXISTS `designation`;
CREATE TABLE IF NOT EXISTS `designation` (
  `d_id` int(11) NOT NULL AUTO_INCREMENT,
  `designation` varchar(30) NOT NULL,
  `d_status` int(11) NOT NULL,
  PRIMARY KEY (`d_id`)
) ENGINE=MyISAM AUTO_INCREMENT=2 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `designation`
--

INSERT INTO `designation` (`d_id`, `designation`, `d_status`) VALUES
(1, 'Manager', 1);

-- --------------------------------------------------------

--
-- Table structure for table `products`
--

DROP TABLE IF EXISTS `products`;
CREATE TABLE IF NOT EXISTS `products` (
  `product_id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(30) NOT NULL,
  `short_disc` varchar(100) NOT NULL,
  `description` varchar(500) NOT NULL,
  `cat_id` int(11) NOT NULL DEFAULT '0',
  `subcat_id` int(11) NOT NULL DEFAULT '0',
  `price` int(11) NOT NULL DEFAULT '0',
  `save_price` int(11) NOT NULL DEFAULT '0',
  `quatity` int(11) NOT NULL DEFAULT '0',
  `product_img` varchar(100) NOT NULL,
  `created_At` datetime NOT NULL,
  PRIMARY KEY (`product_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `staff`
--

DROP TABLE IF EXISTS `staff`;
CREATE TABLE IF NOT EXISTS `staff` (
  `staff_id` int(11) NOT NULL AUTO_INCREMENT,
  `first_name` varchar(30) NOT NULL,
  `last_name` varchar(30) NOT NULL,
  `phone` varchar(100) NOT NULL,
  `address` varchar(200) NOT NULL,
  `gender` varchar(20) NOT NULL,
  `dob` date NOT NULL,
  `designation` varchar(100) NOT NULL,
  `salary` varchar(20) NOT NULL,
  `pic` varchar(100) NOT NULL,
  `user_id` int(11) NOT NULL,
  `status` int(11) NOT NULL DEFAULT '1',
  PRIMARY KEY (`staff_id`)
) ENGINE=InnoDB AUTO_INCREMENT=19 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `staff`
--

INSERT INTO `staff` (`staff_id`, `first_name`, `last_name`, `phone`, `address`, `gender`, `dob`, `designation`, `salary`, `pic`, `user_id`, `status`) VALUES
(14, 'Sinu', 'John', '8767564560', 'Parambil', '1', '1999-05-29', 'Manager', '90000', '', 28, 1),
(15, 'Shilpa', 'james', '6789098978', 'Karukkapallil', '2', '1997-09-29', 'Manager', '50000', '', 29, 1),
(16, 'Nishana', 'Naushad', '9089786756', 'Parambil', '2', '1950-01-01', 'Manager', '60000', '', 30, 0),
(17, 'Rony', 'Tom', '6787898900', 'fsrgxfvcefsdzfgxv', '1', '1951-01-01', 'Manager', '96568', '', 31, 0),
(18, 'Honey', 'Rose', '6541789856', 'Kochumanikunnel', '2', '1950-01-01', '1', '70000', '', 49, 1);

-- --------------------------------------------------------

--
-- Table structure for table `subcategory`
--

DROP TABLE IF EXISTS `subcategory`;
CREATE TABLE IF NOT EXISTS `subcategory` (
  `subcat_id` int(11) NOT NULL AUTO_INCREMENT,
  `subcat_name` varchar(100) NOT NULL,
  `cat_id` int(11) NOT NULL,
  `status` int(11) NOT NULL DEFAULT '1',
  PRIMARY KEY (`subcat_id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `subcategory`
--

INSERT INTO `subcategory` (`subcat_id`, `subcat_name`, `cat_id`, `status`) VALUES
(1, 'qwe', 1, 1);

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

DROP TABLE IF EXISTS `users`;
CREATE TABLE IF NOT EXISTS `users` (
  `users_id` int(11) NOT NULL AUTO_INCREMENT,
  `uname` varchar(30) NOT NULL,
  `email` varchar(200) NOT NULL,
  `password` varchar(200) NOT NULL,
  `is_active` int(11) NOT NULL,
  `role` int(11) NOT NULL,
  `last_login` date NOT NULL,
  `createdAt` date NOT NULL,
  PRIMARY KEY (`users_id`),
  UNIQUE KEY `email` (`email`)
) ENGINE=InnoDB AUTO_INCREMENT=50 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`users_id`, `uname`, `email`, `password`, `is_active`, `role`, `last_login`, `createdAt`) VALUES
(9, 'sobin', 'sobinmathew988@gmail.com', 'c62150305300b6f1df76a04d8d335361e667f74d', 1, 1, '2018-09-06', '2018-09-06'),
(12, 'Steffy', 'steffymathew988@gmail.com', 'c62150305300b6f1df76a04d8d335361e667f74d', 1, 7, '0000-00-00', '2018-09-06'),
(13, 'dona', 'donamathew988@gmail.com', 'c62150305300b6f1df76a04d8d335361e667f74d', 1, 7, '0000-00-00', '2018-09-06'),
(14, 'Admin', 'admin@gmail.com', 'd749208aacb6b40c91bea2aa4dde4c513de04482', 1, 8, '2018-09-14', '2018-09-11'),
(16, 'Asha', 'asha@gmail.com', '38e66ab35a1dad7467ba76b8e5fa120a3d7d720c', 1, 7, '0000-00-00', '2018-09-11'),
(17, 'Subin', 'subin@gmail.com', '972e3426ca9776be73fcb992afd8ea5e10376edc', 1, 7, '2018-09-11', '2018-09-11'),
(18, 'anu', 'anu@gmail.com', 'f218ed743e6c9460faa21ccebae4bd052842eea6', 1, 1, '0000-00-00', '2018-09-11'),
(19, 'Shehu', 'shehu@gmail.com', 'c507f81846dd4abe07b3835b352f62ecf4c1dff2', 1, 1, '0000-00-00', '2018-09-11'),
(20, 'Ammu', 'ammu@gmail.com', '8937c45659b18e36d08aa4cfafc58023cbc5167e', 1, 1, '0000-00-00', '2018-09-11'),
(21, 'qwerty', 'q@gmail.com', 'cde8ccb6e76854c35a55732f457d792c793518f9', 1, 1, '0000-00-00', '2018-09-11'),
(22, 'ertyu', 'df@gmail.com', 'cde8ccb6e76854c35a55732f457d792c793518f9', 1, 1, '0000-00-00', '2018-09-11'),
(23, 'nashi', 'nashi@gmail.com', 'ca746f40839cc9ec96de67f2e71fa9e3e5851091', 1, 1, '2018-09-11', '2018-09-11'),
(24, 'shehu', 'shehana@gmail.com', '77652c4c13bd29889303569da52c2839406d5275', 1, 7, '0000-00-00', '2018-09-12'),
(25, 'tinu', 'tinu@gmail.com', '0ff81f34c44bc50e269703d723b53bd075671b9c', 1, 7, '2018-09-13', '2018-09-13'),
(26, 'appu', 'appu@gmail.com', '69d6809d29f69bc5da443148ccaa60b746f6d8ed', 1, 1, '2018-09-13', '2018-09-13'),
(27, 'ammu', 'ammu12@gmail.com', '31140f13792b94f7adae49c8762f2f0992ec9f87', 1, 7, '0000-00-00', '2018-09-13'),
(28, 'sinu', 'sinu@gmail.com', '5c5ad9c54cc911c429e5cabccfde68dc70175492', 1, 7, '2018-09-13', '2018-09-13'),
(29, 'shilpa', 'shilpa@gmail.com', 'f3bfd65e6fc3202e01daaff499682d39453cc7a7', 1, 7, '0000-00-00', '2018-09-13'),
(30, 'nana', 'nana@gmail.com', '7a2972918c8758aae1d09f7512f1122a975beb3f', 0, 7, '0000-00-00', '2018-09-13'),
(31, 'RonyTom', 'aaa@gmail.com', 'd2dec33519c6719305ef7bf427c737e2665796ce', 0, 7, '0000-00-00', '2018-09-13'),
(32, 'vinu', 'vinu@gmail.com', '227609936cb12d059fb89aa0b25329f650c81b1b', 1, 1, '2018-09-14', '2018-09-14'),
(33, 'annu', 'annu@gmail.com', 'e9286b52a57ab46db94b6c0f704cf00e5487553e', 1, 1, '0000-00-00', '2018-09-14'),
(34, 'binu', 'binu@gmail.com', 'ad51c6a305d70c4831f5655dd86751f11c8e104e', 1, 1, '0000-00-00', '2018-09-14'),
(35, 'manju', 'manju@gmail.com', '3f491e27ae6121b43266b68031707d8c64784847', 1, 1, '0000-00-00', '2018-09-14'),
(36, 'manu', 'manu@gmail.com', '36adaac81f6e4c0f72a004e5396b832976691257', 1, 1, '0000-00-00', '2018-09-14'),
(37, 'amu', 'ammu1@gmail.com', '31140f13792b94f7adae49c8762f2f0992ec9f87', 1, 1, '0000-00-00', '2018-09-14'),
(38, 'anju', 'anju@gmail.com', '6debe430abd150af889cce3e418fe2769b275031', 1, 1, '0000-00-00', '2018-09-14'),
(39, 'qwe', 'qwe@gmail.com', '2986e7e8cb48ff6f44b3ae9ee88c2c52ab864a1b', 1, 1, '0000-00-00', '2018-09-14'),
(40, 'qwer', 'qwer@gmail.com', '10660c6f360dc375d8aba1b2bd668958fd68b617', 1, 1, '0000-00-00', '2018-09-14'),
(41, 'meru', 'merin@gmail.com', 'b15834ec225f8fe6fa28280084b5121f5ec04235', 1, 1, '0000-00-00', '2018-09-14'),
(42, 'kichu', 'kichu@gmail.com', '3c736d4185698ba27aeb54e326a415443229cfa3', 1, 1, '2018-09-14', '2018-09-14'),
(43, 'ajin', 'ajin@gmail.com', 'e6ddc3a71035133f55073bd1a3f41d58bef5c142', 1, 1, '0000-00-00', '2018-09-14'),
(44, 'ajinb', 'ajin2@gmail.com', 'e6ddc3a71035133f55073bd1a3f41d58bef5c142', 1, 1, '0000-00-00', '2018-09-14'),
(45, 'ajinbc', 'ajin2c@gmail.com', 'e6ddc3a71035133f55073bd1a3f41d58bef5c142', 1, 1, '0000-00-00', '2018-09-14'),
(46, 'hegana', 'hegana@gmail.com', 'e6ddc3a71035133f55073bd1a3f41d58bef5c142', 1, 1, '0000-00-00', '2018-09-14'),
(47, 'afgsfg', 'gh@gmail.com', 'e6ddc3a71035133f55073bd1a3f41d58bef5c142', 1, 1, '0000-00-00', '2018-09-14'),
(48, 'ajhjgjkvj', 'ajinbbb@gmail.com', 'e6ddc3a71035133f55073bd1a3f41d58bef5c142', 1, 1, '2018-09-14', '2018-09-14'),
(49, 'hh', 'honey@gmail.com', 'c9bc19b5e6333e29d0dd808f3b9ab69a7cdce724', 1, 7, '0000-00-00', '2018-09-14');
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
